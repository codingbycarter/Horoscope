document.querySelector('#runIt').addEventListener('click', whatAreU)

    function whatAreU(){
        const month = document.querySelector('#month').value
        const day = parseInt(document.querySelector('#day').value)
    // Conditionals
// Leo// 'JULY 23 - AUGUST 22'
if ((month == 'July' && day >= 23) || (month == 'August' && day <= 22)) {
    document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: LEO'
} 
    // Virgo (August 23 - September 22)
 if ((month == 'August' && day >= 23) || (month == 'September' && day <= 22)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Virgo'
    } 
    // Libra (September 23 - October 22)
    if ((month == 'September' && day >= 23) || (month == 'October' && day <= 22)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Libra'
    } 
    // Scorpio (October 23 - November 21)
    if ((month == 'October' && day >= 23) || (month == 'November' && day <= 21)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Scorpio'
    } 
    // Sagittarius (November 22 - December 21)
    if ((month == 'November' && day >= 22) || (month == 'December' && day <= 21)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Sagittarius'
    } 
    // Capricorn (December 22 - January 19)
    if ((month == 'December' && day >= 22) || (month == 'January' && day <= 19)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Capricorn'
    } 
    // Aquarius (January 20 - February 18)
    if ((month == 'January' && day >= 20) || (month == 'February' && day <= 18)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Aquarius'
    } 
    // Pisces (February 19 - March 20)
    if ((month == 'February' && day >= 19) || (month == 'March' && day <= 20)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Pisces'
    } 
    // Aries (March 21 - April 19)
    if ((month == 'March' && day >= 21) || (month == 'April' && day <= 19)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Aries'
    } 
    // Taurus (April 20 - May 20)
    if ((month == 'April' && day >= 20) || (month == 'May' && day <= 20)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Taurus'
    } 
    // Gemini (May 21 - June 20)
    if ((month == 'May' && day >= 21) || (month == 'June' && day <= 20)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Gemini'
    } 
    // Cancer (June 21 - July 22)
    if ((month == 'June' && day >= 21) || (month == 'July' && day <= 22)) {
        document.querySelector('#zodiac').innerText='You are the baddest bitch in the zodiac: Cancer'
    } 
    }